#include<bits/stdc++.h>
using namespace std;

void swap(int* a,int* b){
   int temp=*a;
   *a=*b;
   *b=temp;
}

//selection sort
//step1: swap idx 0 and min_idx number loop from idx[0 to n-1]
//step2: swap idx 1 and min_idx number remaining loop from idx[1 to n-1]
//step3: swap idx 2 and min_idx number remaining loop from idx[2 to n-1] and so on..
void selection_sort(int arr[],int n){
   for(int i=0;i<=n-2;i++){
    int min_idx=i;

    for(int j=i;j<n;j++){
       if(arr[j]<arr[min_idx])min_idx=j;
       }
        //j is the final min_idx of all numbers
        //swap two numbers
        swap(&arr[min_idx],&arr[i]);
}
}



//bubble sort
//step1: idx 0 to n-1 do adjacent swaps with max number to higher index
//step2: idx 0 to n-2 do adjacent swaps with max number to higher index
//step3: idx 0 to n-3 do adjacent swaps with max number to higher index
void bubble_sort(int arr[],int n){
for(int i=n-1;i>=0;i--){
     for(int j=0;j<=i-1;j++){
//swap j and j+1 idx if j is greater than j+1 value
        if (arr[j]>arr[j+1]){
            int temp=arr[j];
            arr[j]=arr[j+1]; 
            arr[j+1]=temp;}
}}}


//Insertion sort
//take first 2,first 3 and so on
//place the last number in the correct position 
//shift it to the lower idx till it comes to the correct place
void insertion_sort(int arr[], int n){
 for(int i=0;i<=n-1;i++){
    int j=i;
    while(j>0 && arr[j-1]>arr[j]){
        swap(&arr[j-1],&arr[j]);
        j--;
}}}


//Merge Sort

void Merge(int arr[],int p, int q, int r){
//create L and R temp arrays of size n1 and n2
   int n1=q-p+1 ;
   int n2=r-q;
   int L[n1], R[n2];

//copy left side elements to L and right side elements to R
   for(int i=0;i<n1;i++)
      L[i]=arr[p+i];
   for(int j=0;j<n2;j++)
      R[j]=arr[q+1+j];

int i=0,j=0,k=p;
while(i<n1 && j<n2){
   if(L[i]<=R[j]){
      arr[k]=L[i];
      i++;
   }else{
      arr[k]=R[j];
      j++;
   }
   k++;
}
//if elements in either L or R complete then insert all remaining elements 
while(i<n1){
   arr[k]=L[i];
   i++;
   k++;
}
while(j<n2){
   arr[k]=R[j];
   j++;
   k++;
}}
void MergeSort(int arr[], int p, int r){
   if(p>=r) return;
   int q=(p+r)/2;
   MergeSort(arr,p, q);
   MergeSort(arr, q+1, r);
   Merge(arr, p, q, r); 
}



//quicksort algorithm

int partition(int arr[],int p,int r){
   int x=arr[r];
   int i=p-1;
   for(int j=p;j<r;j++){
      if(arr[j]<=x){
         swap(arr[j],arr[i+1]);
         i++;+
         
      }
   }
   swap(arr[r],arr[i+1]);
   return i+1;
}

void QuickSort(int arr[],int p,int r){
   if(p>=r)return;
   int q=partition(arr,p,r);
   QuickSort(arr,p,q-1);
   QuickSort(arr,q+1,r);
}



int main(){
   int n;
   cin>>n;
   int arr[n];
for(int i=0;i<n;i++)cin>>arr[i];
                                
cout<<"print before sort:";
for(int i=0;i<n;i++)cout<<arr[i]<<" ";
cout<<endl;

QuickSort(arr,0,n-1);

cout<<"print after sort:";
for(int i=0;i<n;i++)cout<<arr[i]<<" ";

    return 0;
}  