#include<stdio.h>

int max(int a,int b){
    if(a>b)return a;
    return b;
}

//assuming n1>n2
int is_subset(int arr1[],int arr2[],int n1,int n2){
int max1=arr1[0];
for(int i=0;i<n1;i++){
    if(arr1[i]>max1)max1=arr1[i];
}

int max2=arr2[0];
for(int i=0;i<n2;i++){
    if(arr2[i]>max2)max2=arr2[i];
}

int n=max(max1,max2);
int arr[n+1];

for(int i=0;i<n1;i++){
    arr[arr1[i]]=arr1[i];
}

int c=1;
for(int i=0;i<n2;i++){
    if(arr[arr2[i]]==arr2[i])continue;
    else{
        c=0;
        break;
    }
}

if(c==1)return 1;
return 0;

}

int main(){
int n1,n2;
scanf("%d%d",&n1,&n2);
int arr1[n1],arr2[n2];

for(int i=0;i<n1;i++){
    scanf("%d",&arr1[i]);
}

for(int i=0;i<n2;i++){
    scanf("%d",&arr2[i]);
}

if(is_subset(arr1,arr2,n1,n2))printf("Yes");
else printf("No");


}