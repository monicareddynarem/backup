#include<stdio.h>
#include<stdlib.h>

//structure for a node in the adjlist
typedef struct AdjListNode{
    int dest;
    int weight;
    struct AdjListNode* next;
}AdjListNode;

//structure for minheap node
typedef struct MinHeapnode{
    int parent;
    int dist;
}MinHeapNode;

//struct for minheap
typedef struct MinHeap{
    int size;
    int capacity;
    MinHeapNode* arr;
}MinHeap;

//to createa a new node with given destinationand weight
AdjListNode* newAdjListNode(int dest, int weight) {
    AdjListNode* newNode = (AdjListNode*)malloc(sizeof(AdjListNode));
    newNode->dest = dest;
    newNode->weight = weight;
    newNode->next = NULL;
    return newNode;
}

//to add edge to a graph
//for undirected graph write two times interchanging source and destination
void addEdge(AdjListNode* AdjList[],int src,int dest,int weight){
    AdjListNode* newnode=newAdjListNode(dest,weight);
    newnode->next=AdjList[src];
    AdjList[src]=newnode;
}

//create minheap node
MinHeapNode* newMinHeapNode(int parent,int dist){
MinHeapNode* newheapnode=(MinHeapNode*)malloc(sizeof(MinHeapNode));
newheapnode->parent=parent;
newheapnode->dist=dist;
return newheapnode;
}

//create min heap
MinHeap* createMinHeap(int capacity){
    MinHeap* minheap=(MinHeap*)malloc(sizeof(MinHeap));
    minheap->size=0;
    minheap->capacity=capacity;
    minheap->arr=(MinHeapNode*)malloc(capacity*sizeof(MinHeapNode));
    return minheap;
}

void swapMinHeapNodes(MinHeapNode* a,MinHeapNode* b){
    int dist1=a->dist;
    int parent1=a->parent;
    a->dist=b->dist;
    a->parent=b->parent;
    b->dist=dist1;
    b->parent=parent1;
}

void SwapHeapNodes(MinHeapNode a,MinHeapNode b){
    int p1=a.parent;
    int d1=a.dist;
    a.dist=b.dist;
    a.parent=b.parent;
    b.parent=p1;
    b.dist=d1;
}


//heapify for minheap function
void minHeapify(MinHeap* minHeap,int i){
    int small=i;
    int lc=2*i+1;
    int rc=2*i+2;
    if(lc < minHeap->size && minHeap->arr[lc].dist< minHeap->arr[small].dist){
        small=lc;
    }
    if(rc < minHeap->size && minHeap->arr[rc].dist < minHeap->arr[small].dist){
        small=rc;
    }

if(small!=i){
swapMinHeapNodes(&minHeap->arr[small],&minHeap->arr[i]);
minHeapify(minHeap,small);
}
}

int isEmpty(MinHeap* minHeap){
    return minHeap->size==0;
}

MinHeapNode* extractMin(MinHeap* minheap){
if(isEmpty(minheap))return NULL;
MinHeapNode* newnode=newMinHeapNode(minheap->arr[0].parent,minheap->arr[0].dist);
minheap->arr[0].dist=minheap->arr[minheap->size-1].dist;
minheap->arr[0].parent=minheap->arr[minheap->size-1].parent;
minheap->size--;
minHeapify(minheap,0);
return newnode;
}


int main(){
int V=6;
AdjListNode* AdjList[V];

 for (int i = 0; i < V;i++) {
        AdjList[i] = NULL; // Initialize adjacency list
    }

    return 0;
}