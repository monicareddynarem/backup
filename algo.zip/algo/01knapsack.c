#include<stdio.h>

int max(int a,int b){
    if(a>b)return a;
    else return b;
}

void ks01(int w[],int v[],int n,int c,int result[]){
int t[n+1][c+1];
for(int i=0;i<n+1;i++){
    for(int j=0;j<c+1;j++){
        if(i==0||j==0)t[i][j]=0;
    
    if(w[i]>j)t[i][j]=t[i-1][j];
    else t[i][j]=max(t[i-1][j],v[i-1]+t[j-w[i-1]]);}
}
int j=c;
int k=0;=
for(int i=n;i>=1;i--){
    if(t[i][j]>t[i-1][j]){
        result[k]=i;
        k++;
        j=j-w[i];
}
}
return;}



int main(){
    int n,c;
    scanf("%d%d",&n, &c);
    int w[n];
    int v[n];
    int result[n];
    

for(int i=0;i<n;i++){
    scanf("%d%d",&w[i],&v[i]);
}
for(int i=0;i<n;i++){result[i]=0;}

ks01(w,v,n,c,result);

int m=0;
while(result[m]!=0){
    printf("%d  ",result[m]);
    m++;
}


return 0;
}