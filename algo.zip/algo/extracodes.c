//elements in a bst
void insert(Node* root, int key){
    Node* prev=NULL;
    while(root!=NULL){
        prev=root;
        if(root->data==key)return;  //element is already in bst
        else if(key < root->data)root=root->left;
        else root=root->right;
    }
Node* new=newNode(key);
if(key < prev->data)prev->left=new;
else prev->right=new;
}


//deleting a node
Node* delNode(Node* root,int key){
    if(root==NULL)return NULL;
    if(root->left==NULL && root->right==NULL){
        free(root);
        return NULL;
    }
if(key < root->data)root->left=delNode(root->left,key);
else if(key > root->data)root->right=delNode(root->right,key);
else{
    Node* iPre=inOrderPre(curr,root);//find a way to store the main root in a node,it should not change in each recursion
    root->data=iPre->data;
    root->left=delNode(root->left,iPre->data);
}
return root;
}