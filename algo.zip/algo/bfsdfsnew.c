#include<stdio.h>
#include<stdlib.h>
#define MAX_VERTICES 100
typedef struct Node{
    int value;
    struct Node* next;
}Node;

Node* createNode(int value){
    Node* newnode=(Node*)malloc(sizeof(Node));
    newnode->value=value;
    newnode->next=NULL;
    return newnode;
}

void addEdge(Node* adj[],int u,int v){
    Node* node=createNode(v);
    node->next=adj[u];
    adj[u]=node;
}

void bfs(Node* adj[],int s,int visited[]){
int que[MAX_VERTICES];
int front=0,rear=0;
visited[s]=1;//source as visited
que[rear]=s;
rear++;

while(front!=rear){
    int curr=que[front];
    front++;
    printf("%d",curr);

    Node* temp=adj[curr];
    while(temp!=NULL){
        int nbr=temp->value;
        if(!visited[nbr]){
            visited[nbr]=1;
            que[rear]=nbr;
            rear++;
        }
        temp=temp->next;
    }
}
}

void bfsDisconnected(Node* adj[], int V)
{   int visited[V];
    for (int i = 0; i < V; i++) {
        visited[i] = 0;
    }
    for (int i = 0; i < V; ++i) {
        if (!visited[i]) {
            bfs(adj, i, visited);
        }
    }
}



void dfs(Node* adj[],int s,int visited[]){
int stack[MAX_VERTICES];
int top=0,bottom=0;
visited[s]=1;//source as visited
stack[top]=s;
top++; 

while(top!=bottom){
    int curr=stack[top-1];
    top--;
    printf("%d",curr);

    Node* temp=adj[curr];
    while(temp!=NULL){
        int nbr=temp->value;
        if(!visited[nbr]){
            visited[nbr]=1;
            stack[top]=nbr;
            top++;
        }
        temp=temp->next;
    }
}
}


void dfsDisconnected(Node* adj[], int V)
{   int visited[V];
    for (int i = 0; i < V; i++) {
        visited[i] = 0;
    }
    for (int i = 0; i < V; ++i) {
        if (!visited[i]) {
            dfs(adj, i, visited);
        }
    }
}




int main(){

     int V = 6; // Number of vertices
     Node* adj[V];

    for (int i = 0; i < V; ++i) {
        adj[i] = NULL; // Initialize adjacency list
    }
    addEdge(adj, 0, 1);
    addEdge(adj, 1, 0);
    addEdge(adj, 0, 2);
    addEdge(adj, 2, 0);
    addEdge(adj, 3, 4);
    addEdge(adj, 4, 3);
    addEdge(adj, 4, 5); 
    addEdge(adj, 5, 4);
    // Perform BFS traversal for the entire graph
    bfsDisconnected(adj, V);

    return 0;


}