// #include<bits/stdc++.h>
#include<iostream>
#include<cmath>
using namespace std;


typedef struct Chamber{
    int sl;
    int bjl;
    int time;

    int jv() const { return sl * bjl; }
    int ttd() const { return time * sl; }
}Chamber;


int main()
{
    int n,t;
    cin>>n>>t;

    Chamber chambers[n];
    for(int i=0;i<n;i++){
        cin>>chambers[i].sl>>chambers[i].bjl>>chambers[i].time;
    }
    
    int times[n];
    int value[n];
    for(int i=0;i<n;i++){
        times[i]=chambers[i].ttd();
        value[i]=chambers[i].jv();
    }

    int dp[n+1][t+1];

    for(int i=0;i<=n;i++){
        for(int j=0;j<=t;j++){
            if(i==0 || j==0){
                dp[i][j]=0;
            }
           else{
           if(times[i-1]>j)dp[i][j]=dp[i-1][j];
           else{
            dp[i][j]=max(dp[i-1][j],value[i-1]+dp[i-1][j-times[i-1]]);
           }
           }
        }
    }

cout<<dp[n][t];

    return 0;
}