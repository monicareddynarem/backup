#include<stdio.h>
#include<malloc.h>

int max(int a,int b){
    if(a>b)return a;
    return b;
}
typedef struct node{
    int data;
    struct node* left;
    struct node* right;
}Node;

//creating a new node and assigning it to a pointer
Node* newNode(int value){
Node* n=(Node*)malloc(sizeof(Node));
n->data=value;
n->left=NULL;
n->right=NULL;
return n;
}

//printing preorder sequence
void PreOrder(Node* root){
    if(root!=NULL){
        printf("%d ",root->data);
        PreOrder(root->left);
        PreOrder(root->right);
    }
    return;
}

//printing postorder sequence
void PostOrder(Node* root){
    if(root!=NULL){
        PostOrder(root->left);
        PostOrder(root->right);
        printf("%d ",root->data);
    }
    return;
}

//printing inorder sequence
void InOrder(Node* root){
    if(root!=NULL){
        InOrder(root->left);
        printf("%d ",root->data);
        InOrder(root->right);
    }
    return;
}

//minvalue of a tree
Node* minValue(Node* node){
    Node* current=node;
    while(current->left !=NULL){
        current=current->left;
    }
    return current;
}

//maxvalue of a tree
Node* maxValue(Node* node){
    Node* current=node;
    while(current->right!=NULL){
        current=current->right;
    }
    return current;
}

//inorder successor 
Node* inOrderSuc(Node* root,Node* n){
    if(n->right !=NULL)return minValue(n->right);
    Node* succ=NULL;

    while(root!=NULL){
        if(n->data < root->data){
            succ=root;
            root=root->left;
        }
        else if(n->data > root->data)
            root=root->right;
        else break;
    }
    return succ;
}

//inorder predecessor
Node* inOrderPre(Node* root,Node* n){
    if(n->left!=NULL)return maxValue(n->left);
    Node* Pre=NULL;

    while(root!=NULL){
        if(n->data > root->data){
            Pre=root;
            root=root->right;
        }
        else if(n->data < root->data) 
            root=root->left;
        else break;
    }
    return Pre;
}


Node* insert(Node* root,int x){
    if(root==NULL)return newNode(x);
    if(x >=root->data)root->right=insert(root->right,x);
    else if(x < root->data)root->left=insert(root->left,x);
    return root;
}

int Search(Node* root,int x){
    if(root==NULL)return 0;
    if(x>root->data){
        return Search(root->right,x);
    }
    else if(x<root->data){
        return Search(root->left,x);
    }
    else{
        1+Search(root->right,x);
    }
}


Node* Delete(Node* root,int x){
if(root==NULL)return NULL;
if(x>root->data)root->right=Delete(root->right,x);
else if(x<root->data)root->left=Delete(root->left,x);
else{
    if(root->left==NULL){
    Node* temp=root->right;
    free(root);
    return temp;
   }
    else if(root->right==NULL){
    Node* temp=root->left;
    free(root);  
    return temp;
   }
    else{
    Node* temp=minValue(root->right);
    root->data=temp->data;
    root->right=Delete(root->right, temp->data);
   }
}
return root;
}

Node* searchkey(Node* root,int x){
    if(root==NULL)return NULL;
    if(x==root->data)return root;
    else if(x>root->data)return searchkey(root->right,x);
    else return searchkey(root->left,x);
}


Node* deleteall(Node* root,int x){
Node* n=searchkey(root,x);
while(n->data!=x){
    n=Delete(n,x);
}
return root;
}

int height(Node* x){
if(x==NULL)return 0;
return 1+ max(height(x->left),height(x->right));}

void printcurrentlevel(Node* root,int level){
    if(root==NULL)return;
    if(level==1)printf("%d ",root->data);
    else if(level>1){
        printcurrentlevel(root->left,level-1);
        printcurrentlevel(root->right,level-1);
    }
}
void printlevelorder(Node* root){
    int h=height(root);
    for(int i=1;i<=h;i++){
        printcurrentlevel(root,i);
        printf("\n");
    }
}

int main(){
int n;
scanf("%d",&n);
Node* root=NULL;
for(int i=0;i<n;i++){
    int p;
    scanf("%d",&p);
    root=insert(root,p);
    }

printlevelorder(root);
printf("\n");
root=deleteall(root,20);
printlevelorder(root);



return 0;
}