#include<stdio.h>
#include<malloc.h>
#include<math.h>

int max(int a,int b){
    if (a>b) return a;
    return b;
}

typedef struct NODE{
    int data;
    struct NODE* left;
    struct NODE* right;
    int height;
}Node;

int getHeight(Node* root){
    if(root==NULL)return 0;
    return root->height;
}

Node* createnode(int key){
    Node* node=(Node*)malloc(sizeof(Node));
    node->data=key;
    node->left=NULL;
    node->right=NULL;
    node->height=1; 
    return node;
}

void InOrder(Node* root){
    if(root!=NULL){
        InOrder(root->left);
        printf("%d\n",root->data);
        InOrder(root->right);
    }
    return;
}

int getBalance(Node* root){
    if(root==NULL)return 0;
    return getHeight(root->left) - getHeight(root->right);
}

int height(Node* x){
if(x==NULL)return 0;
return 1+ max(height(x->left),height(x->right));}

Node* minValue(Node* node){
    Node* current=node;
    while(current->left !=NULL){
        current=current->left;
    }
    return current;
}

void printcurrentlevel(Node* root,int level){
    if(root==NULL)return;
    if(level==1)printf("%d",root->data);
    else if(level>1){
        printcurrentlevel(root->left,level-1);
        printcurrentlevel(root->right,level-1);
    }
}

void printlevelorder(Node* root){
    int h=height(root);
    for(int i=1;i<=h;i++){
        printcurrentlevel(root,i);
        printf("\n");
    }
}

Node* leftRotate(Node* x){
    Node* y=x->right;
    Node* z=y->left;
    y->left=x;
    x->right=z;
    y->height=height(y);  
    x->height=height(x);
    return y;
}

Node* rightRotate(Node* y){
    Node* x=y->left;
    Node* z=x->right;
    x->right=y;
    y->left=z;
    y->height=height(y);
    x->height=height(x);
    return x; 
}

//inserting node
Node* insert(Node* root,int key){
    if(root==NULL)return createnode(key);
    if(key<root->data)
        root->left=insert(root->left,key);
    else if(key>root->data)
        root->right=insert(root->right,key);
    else {
        printf("key already present:(only balancing)");
        return root;}

int balance=getBalance(root);
if(balance>1){                              //left heavy
    if(key > root->left->data){                //left-right
        root->left=leftRotate(root->left);}
    return rightRotate(root);                   //left left
}
else if(balance<-1){                              //right heavy
    if(key < root->right->data){                  //right-left
        root->right=rightRotate(root->right);}
    return leftRotate(root);                    //right-right
}
root->height=height(root);
return root;
}

//delete node
Node* delNode(Node* root,int key){
if(root==NULL)return NULL;
if(key < root->data)root->left=delNode(root->left,key);
else if(key > root->data)root->right=delNode(root->right,key);
else{
     if(root->left==NULL){
    Node* temp=root->right;
    free(root);
    return temp;
   }
    else if(root->right==NULL){
    Node* temp=root->left;
    free(root);  
    return temp;
   }
    else{
    Node* temp=minValue(root->right);
    root->data=temp->data;
    root->right=delNode(root->right, temp->data);
   }
}
int balance=getBalance(root);
if(balance>1){                              //left heavy
    if(key > root->left->data){                //left-right
        root->left=leftRotate(root->left);}
    return rightRotate(root);                   //left left
}
else if(balance<-1){                              //right heavy
    if(key < root->right->data){                  //right-left
        root->right=rightRotate(root->right);}
    return leftRotate(root);                    //right-right
}
root->height=height(root);
return root;
}




int main(){

Node* root=NULL;
root=insert(root,5);
root=insert(root,3);
root=insert(root,6);
root=insert(root,1);
root=insert(root,4);
root=insert(root,9);
root=insert(root,2);
root=insert(root,8);
root=insert(root,7);
root=insert(root,10);


printlevelorder(root);

 
    return 0;


}