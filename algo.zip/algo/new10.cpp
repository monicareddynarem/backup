#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {

    #ifndef ONLINE_JUDGE
freopen("input.txt", "r", stdin);
freopen("output.txt", "w", stdout);
#endif
    int t;
    cin >> t;  // Read number of test cases
    while (t--) {
        int n, k;
        cin >> n >> k;  // Read n and k
        vector<int> a(n);
        for (int i = 0; i < n; i++) {
            cin >> a[i];  // Read the array a
        }

        vector<int> even_indices_values;

        // Extract the values from the even indexed subarrays
        for (int i = k - 1; i < n; i += 2) {
            even_indices_values.push_back(a[i]);
        }

        // Sort these values to minimize the cost
        sort(even_indices_values.begin(), even_indices_values.end());

        // Calculate the minimum cost
        int min_cost = 1;  // The smallest possible cost is 1 (if b[1] != 1)
        for (int i = 0; i < even_indices_values.size(); i++) {
            if (even_indices_values[i] != (i + 1)) {
                min_cost = i + 1;
                break;
            }
        }

        // Output the result for the current test case
        cout << min_cost << endl;
    }

    return 0;
}
