#include<stdio.h>
#include<malloc.h>

typedef struct node{
     int nkey;//no.of keys in node
     int* arr;
}Node;

typedef struct heap{
    int p;//node capacity
    int n;//keys
    int N;//nodes in use
    Node* node;

}Heap;


//p is node capacity;
//n is no. of keys
Heap initheap(int p,int n){
   Heap H;
   int N,i;
   H.p=p;//initialize node capacity
   H.n=0;//number of keys
   H.N=0;//intial number of noeds used

   N=(n+p-1)/p;//no of nodes in use
//H.node is an array of nodes
   H.node=(Node*)malloc((N)*sizeof(Node));
   for(i=0;i<N;++i){
    H.node[i].nkey=0;
    H.node[i].arr=(int*)malloc(p*sizeof(int));//a node can store max of p elements
   }
return H;
}

void printHeap(Heap H){
    for(int i=0;i<H.N;i++){
        printf("  [");
        for(int j=0;j<H.node[i].nkey;j++){
            printf("%d ",H.node[i].arr[j]);
        }
        printf("]\n");
    }
}

Heap insert(Heap H,int x){
    int i,j,u,v,nmax,pmin,s,*K;
    K=(int*)malloc(2*H.p*sizeof(int));
    H.N=(H.n+H.p-1)/p;
    i=H.N-1;//i is the indexof last node;
    H.node[i].key[H.node[i].nkey]=x;//considering last node has not complete p keys
    H.node[i].nkey++;
    while(1){
        if(i==0)break;//if number of nodes are 1/starting index=0;
        +



    }

    
}



int main(){



    return 0;

}