#include<stdio.h>
#include<malloc.h>


void swap(int*a, int*b){
    int temp=*a;
    *a=*b;
    *b=temp;
}
//0 indexing heap implementation
/*node of index i-left child-2i+1
                 -right child-2i+2
                 -parent-(i-1)/2
last non leaf node-parent of the last node:last node index=n-1
           last non leaf node-(n-2)/2
*/


typedef struct Heap{
    int* arr;
    int size;
    int capacity;
}Heap;

Heap* createHeap(int capacity){
    Heap* heap=(Heap*)malloc(sizeof(heap));
    heap->size=0;
    heap->capacity=capacity;
    heap->arr=(int*)malloc(capacity*sizeof(int));
    return heap;
}

/*MAX HEAP*/

//heapify at node of index i
void heapify(Heap* heap, int i){
    int largest=i;
    int lc=2*i+1;
    int rc=2*i+2;
//if lc exists and greater than current then largest =lc
    if(lc < heap->size && heap->arr[lc] > heap->arr[largest]){
        largest=lc;
    }
//if rc exists and greater than largest then largest =rc
    if(rc < heap->size && heap->arr[rc] > heap->arr[largest]){
        largest=rc;
    }
    if(largest!=i){
        swap(&heap->arr[i] , &heap->arr[largest]);
        heapify(heap,largest);
    }
}

//building an entire heap from an array
void buildHeap(Heap* heap){
    int n=heap->size;
//start from last non leaf node and heapify for all indexes upto 0
    for(int i=(n-2)/2; i>=0; i--){
        heapify(heap,i);
    }
}




void printHeap(Heap* heap)
{
    for (int i = 0; i < heap->size; ++i)
        printf("%d ", heap->arr[i]);
    printf("\n");
}

int main(){
Heap* heap=createHeap(20);
insert(heap,5);
insert(heap,2);
insert(heap,10);
insert(heap,15);
insert(heap,6);
insert(heap,1);


printHeap(heap);

return 0;
}