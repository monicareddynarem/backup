#include<stdio.h>
#include<malloc.h>

int max(int a,int b){
    if(a>b)return a;
    return b;
}

int min(int a,int b){
    if(a<b)return a;
    return b;
}
typedef struct node{
    int data;
    struct node* left;
    struct node* right;
}Node;

//creating a new node and assigning it to a pointer
Node* createNode(int value){
Node* n=(Node*)malloc(sizeof(Node));
n->data=value;
n->left=NULL;
n->right=NULL;
return n;
}

int height(Node* root){
        if(root==NULL)return 0;
    return 1+max(height(root->right),height(root->left));
}

int minheight(Node* root){
    if(root==NULL)return 0;
    return 1+min(height(root->right),height(root->left));
}

// void setsucc(Node* root,Node* prev){
//     if(root==NULL)return;
//     setsucc(root->left,prev);
//     if(prev!=NULL)prev->insuc=root;
//     prev=root;
//     setsucc(root->right,prev);}

//     void printInOrderSuccessors(Node* root) {
//     Node* current = root;
//     while (current && current->left) {
//         current = current->left;
//     }
//     while (current) {
//         if (current->insuc) {
//             printf("In-order successor of %d is %d",current->data,current->insuc->data);
        
//         }else{
//             printf("%d has no in-order successor",current->data);
//         }
//         current = current->insuc;
//     }
// }

int nodes(Node* root){
    if(root==NULL)return 0;
    return 1+nodes(root->left)+nodes(root->right);
}

//inorder succesor
Node* getSucc(Node* root,Node* target,Node** last) {
    if(root==NULL)return NULL;
    Node* succ = getSucc(root->right, target, last);
    if (succ!=NULL) return succ;
    if (root->data == target->data)return *last;
    *last = root;
    return getSucc(root->left, target, last);
}

int heightmax(Node* root){
    if(root==NULL)return 0;
    return 1+max(height(root->right),height(root->left));  
}


void hops(Node* root);


int main(){
Node* root = createNode(5);
root->left = createNode(9);
root->right = createNode(7);
root->left->left = createNode(3);
root->right->left = createNode(4);
root->right->right = createNode(1);
root->right->right->left = createNode(6);
root->right->right->right = createNode(2);




// printInOrderSuccessors(root);

return 0;}

int j=0;
void hops(Node* root){
    
int h=height(root);
int n=nodes(root);
int arr[h-1][n];
for(int i=0;i<h-1;i++){
    for(int j=0;j<n;j++){
        arr[i][j]=0;
    }
}

    if(root==NULL)return;
int hp=minheight(root)-1;
arr[hp][j]=root->data;
j++;
return hops(root->left);
return hops(root->right);
}
