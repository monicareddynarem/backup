#include<stdio.h>
#include<malloc.h?>
#include<stdlib.h>

#define MAX_SIZE 100

void swap(job* j1,job* j2){
    job* t=j1;
    j1=j2;
    j2=t;
}
typedef struct job{
    int jobid;
    int starttime;
    int joblength;
    int remlength;
}job;

//assuming max no. of jobs 99
typedef struct heap{
    job list[MAX_SIZE];
    int numjobs;
}heap;

void initHeap(heap* H){
    H->numjobs=0;
}

//1 indexing
void insertJob(heap* H,job j){
    if(H->numjobs==MAX_SIZE){
        return;//heap overflow
    }
    j.remlength=j.joblength;
    numjobs++;
    H->list[numjobs]=j;
    i=numjobs;//last index
    while(i!=1 && H->list[i/2].remlength > H->list[i].remlength){
       swap(&H->list[i/2], &H->list[i]);
       i=i/2;
    }
}

void heapify(heap* H,int i){
    int min=i;
    int lc=2*i;
    int rc=2*i+1;
    
    if(lc <= H->numjobs && H->list[lc]<H->list[min]){
        min=lc;
    }
    if(rc <= H->numjobs && H->list[rc]<H->list[min]){
        min=rc;
    }
    if(min!=i){
        swap(&H->arr[i],&H->arr[min]);
        heapify(H,min);
    }
}

int extractMin(heap* H,job* J){
if(H->numjobs==0)return -1;
swap(&H->list[1],&H->list[H->numjobs]);
*J=H->list[H->numjobs];
H->numjobs--;
//heapify
heapify(H,1);
return 0;
}


void scheduler(job jobList[],int n){
    
}


int main(){





    return 0;
}