#include<stdio.h>
#include<malloc.h>

typedef struct node{
    int data;
    struct node* left;
    struct node* right;
}Node;

//creating a new node and assigning it to a pointer
Node* newNode(int value){
Node* n=(Node*)malloc(sizeof(Node));
n->data=value;
n->left=NULL;
n->right=NULL;
return n;
}

//check if a tree is symmetric
int isEqual(Node* root1,Node* root2){
    if(root1!=NULL && root2!=NULL){
        if(root1->data==root2->data){
            return (isEqual(root1->right,root2->left) && isEqual(root1->left,root2->right));
        }
        return 0;
    }
    if(!root1 && !root2)return 1;
    return 0;
}
int isSym(Node* root){
    return isEqual(root->left,root->right);
}



#include<iostream>
#include<stack>

using namespace std;

struct TreeNode {
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};

void zigzagTraversal(TreeNode* root) {
    if (!root) return;

    stack<TreeNode*> currentLevel;
    stack<TreeNode*> nextLevel;

    bool leftToRight = true;
    currentLevel.push(root);

    while (!currentLevel.empty()) {
        TreeNode* currentNode = currentLevel.top();
        currentLevel.pop();

        cout << currentNode->val << " ";

        if (leftToRight) {
            if (currentNode->left) nextLevel.push(currentNode->left);
            if (currentNode->right) nextLevel.push(currentNode->right);
        }
        else {
            if (currentNode->right) nextLevel.push(currentNode->right);
            if (currentNode->left) nextLevel.push(currentNode->left);
        }

        if (currentLevel.empty()) {
            leftToRight = !leftToRight;
            swap(currentLevel, nextLevel);
        }
    }
}

int main() {
    TreeNode* root = new TreeNode(1);
    root->left = new TreeNode(2);
    root->right = new TreeNode(3);
    root->left->left = new TreeNode(4);
    root->left->right = new TreeNode(5);
    root->right->left = new TreeNode(6);
    root->right->right = new TreeNode(7);

    zigzagTraversal(root);

    return 0;
}



struct Node {
    int val;
    Node* left;
    Node* right;
    Node(int v) : val(v), left(nullptr), right(nullptr) {}
};

void zigzagTraversal(Node* root, int level, bool direction) {
    if (!root) {
        return;
    }
    if (level == 1) {
        cout << root->val << " ";
    } else if (level > 1) {
        if (direction) {
            zigzagTraversal(root->left, level - 1, direction);
            zigzagTraversal(root->right, level - 1, direction);
        } else {
            zigzagTraversal(root->right, level - 1, direction);
            zigzagTraversal(root->left, level - 1, direction);
        }
    }
}

int height(Node* root) {
    if (!root) {
        return 0;
    }
    int leftHeight = height(root->left);
    int rightHeight = height(root->right);
    return max(leftHeight, rightHeight) + 1;
}

void zigzagTraversal(Node* root) {
    if (!root) {
        return;
    }
    int h = height(root);
    bool direction = true; // true: left-to-right, false: right-to-left
    for (int i = 1; i <= h; i++) {
        zigzagTraversal(root, i, direction);
        direction = !direction;
    }
}

int main() {
    Node* root = new Node(1);
    root->left = new Node(2);
    root->right = new Node(3);
    root->left->left = new Node(4);
    root->left->right = new Node(5);
    root->right->left = new Node(6);
    root->right->right = new Node(7);
    cout << "Zigzag traversal: ";
    zigzagTraversal(root);
    cout << endl;
    return 0;
} 