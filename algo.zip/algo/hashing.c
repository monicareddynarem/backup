#include<stdio.h>
#include<stdlib.h>

int max(int a,int b){
    if(a>b)return a;
    return b;
}


// int exhsearch(int i,int u,int v,int L,int arr[],int n){
//     if(i==n)return i;
//     if(L-u<arr[i] && L-v<arr[i])return i;
//     return 1+max(exhsearch(i+1,u+arr[i],v,L,arr,n),exhsearch(i+1,u,v+arr[i],L,arr,n));
// }




int main(){
    int L,n;
    scanf("%d%d",&L,&n);
    int arr[n];
    for(int i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }



    return 0;
}