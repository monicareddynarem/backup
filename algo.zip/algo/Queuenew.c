#include<stdio.h>
#include<stdbool.h>
#define MaxSize 100

typedef struct que{
    int items[MaxSize];
    int front;
    int back;
}Queue;

void initializeQueue(Queue* q){
    q->front=-1;
    q->back=0;
}

//considering back is the after last indexing
//and front is before the first element indexig
bool isEmpty(Queue* q){
    return (q->front==q->back-1);
}

bool isFull(Queue* q){
    return (q->back==MaxSize);
}

void enqueue(Queue* q,int value){
    if(isFull(q)){
        printf("queue is full");
        return;
    }
    q->items[q->back]=value;
    q->back++;
}

void dequeue(Queue* q){
    if(isEmpty(q)){
        printf("queue is empty");
        return;
    }
    q->front++;
}

int peek(Queue* q){
    if(isEmpty(q)){
        printf("q is empty");
        return -1;
    }
    return q->items[q->front+1];
}

void printQueue(Queue* q){
    if(isEmpty(q)){
        printf("queue is empty");
        return;
    }

    printf("queue:");
    for(int i=q->front+1;i<q->back;i++){
        printf("%d",q->items[i]);
    }
    printf("/n");
}
