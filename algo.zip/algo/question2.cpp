#include<bits/stdc++.h>
#include<cctype>

using namespace std;

bool hasUppercase(const string& str) {
    for (char ch : str) {
        if (isupper(ch)) {
            return true;
        }
    }
    return false;
}

bool hasLowercase(const string& str) {
    for (char ch : str) {
        if (islower(ch)) {
            return true;
        }
    }
    return false;
}


bool con3letters(const string& str) {
    int count = 0;
    for (char ch : str) {
        if (isalpha(ch)) { 
            count++;
            if (count == 3) {
                return true;
        } else {
            count = 0;
    }
    return false;
        }
    }
}


int solution(string s){
if(hasUppercase(s) && hasLowercase(s)){

}
else if(!hasUppercase(s) && hasLowercase(s)){

}
else if(hasUppercase(s) && !hasLowercase(s)){

}
}



int main()
{int N,X,Y;
cin>>N>>X>>Y;

cout<<amount(2,5,9);
    return 0;
}