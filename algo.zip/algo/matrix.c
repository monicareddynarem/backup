#include <stdio.h>
#include <limits.h>

// Function to calculate min multiplication cost
int minMult(int arr[], int n) {
    // Create a 2D DP array to store minimum
    // multiplication costs
    int dp[n][n];
    
    // Initialize DP array with 0s
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            dp[i][j] = 0;
        }
    }
    
    // Fill the DP array
    // len is the chain length
    for (int len = 2; len < n; len++) {
        for (int i = 0; i < n - len; i++) {
            int j = i + len;
            dp[i][j] = INT_MAX;
            
            for (int k = i + 1; k < j; k++) {
                int cost = dp[i][k] + dp[k][j] +
                  arr[i] * arr[k] * arr[j];
                if (cost < dp[i][j]) {
                    dp[i][j] = cost;
                }
            }
        }
    }
    
    // Minimum cost is in dp[0][n-1]
    return dp[0][n - 1];
}

int main() {
    int arr[] = {2,3,4,2};
    int n = sizeof(arr) / sizeof(arr[0]);
    printf("%d\n", minMult(arr, n));
    return 0;}