#include <stdio.h>
#include <stdlib.h>

// Structure to represent a node in the adjacency list
typedef struct AdjListNode {
    int dest;
    struct AdjListNode* next;
} AdjListNode;

// Structure to represent an adjacency list
typedef struct AdjList {
    AdjListNode* head;
} AdjList;

// Structure to represent a graph
typedef struct Graph {
    int V;
    AdjList* array;
} Graph;

// Stack structure for topological sort
typedef struct Stack {
    int* data;
    int top;
} Stack;

// Function to create a stack
Stack* createStack(int capacity) {
    Stack* stack = (Stack*)malloc(sizeof(Stack));
    stack->data = (int*)malloc(capacity * sizeof(int));
    stack->top = -1;
    return stack;
}

void push(Stack* stack, int value) {
    stack->data[++stack->top] = value;
}

int pop(Stack* stack) {
    return stack->data[stack->top--];
}

int isEmpty(Stack* stack) {
    return stack->top == -1;
}

// Function to create a new adjacency list node
AdjListNode* newAdjListNode(int dest) {
    AdjListNode* newNode = (AdjListNode*)malloc(sizeof(AdjListNode));
    newNode->dest = dest;
    newNode->next = NULL;
    return newNode;
}

// Function to create a graph with V vertices
Graph* createGraph(int V) {
    Graph* graph = (Graph*)malloc(sizeof(Graph));
    graph->V = V;
    graph->array = (AdjList*)malloc(V * sizeof(AdjList));
    for (int i = 0; i < V; ++i)
        graph->array[i].head = NULL;
    return graph;
}

// Function to add an edge to the graph (directed graph)
void addEdge(Graph* graph, int src, int dest) {
    AdjListNode* newNode = newAdjListNode(dest);
    newNode->next = graph->array[src].head;
    graph->array[src].head = newNode;
}

// Recursive function for topological sort
void topologicalSortUtil(Graph* graph, int v, int* visited, Stack* stack) {
    visited[v] = 1;  // Mark the current node as visited

    // Recur for all adjacent vertices
    AdjListNode* current = graph->array[v].head;
    while (current != NULL) {
        if (!visited[current->dest])
            topologicalSortUtil(graph, current->dest, visited, stack);
        current = current->next;
    }

    // Push the current vertex to stack that holds the result
    push(stack, v);
}

// Function to perform topological sort
void topologicalSort(Graph* graph) {
    Stack* stack = createStack(graph->V);

    // Mark all vertices as not visited
    int* visited = (int*)malloc(graph->V * sizeof(int));
    for (int i = 0; i < graph->V; i++)
        visited[i] = 0;

    // Call the recursive helper function to store topological
    // sort for each vertex
    for (int i = 0; i < graph->V; i++) {
        if (visited[i] == 0)
            topologicalSortUtil(graph, i, visited, stack);
    }

    // Print the contents of the stack (topological order)
    printf("Topological Sort:\n");
    while (!isEmpty(stack)) {
        printf("%d ", pop(stack));
    }
    printf("\n");

    free(visited);
    free(stack->data);
    free(stack);
}

// Main function to test the topological sort
int main() {
    int V = 6;
    Graph* graph = createGraph(V);
    addEdge(graph, 5, 2);
    addEdge(graph, 5, 0);
    addEdge(graph, 4, 0);
    addEdge(graph, 4, 1);
    addEdge(graph, 2, 3);
    addEdge(graph, 3, 1);

    topologicalSort(graph);

    return 0;
}