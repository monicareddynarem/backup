#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>


void swap(int* a,int* b){
    int temp=*a;
    *a=*b;
    *b=temp;
}

typedef struct heap{
    int* arr;
    int size;
    int capacity;
}Heap;

Heap* createheap(int capacity){
Heap* heap=(Heap*)malloc(sizeof(Heap));
heap->capacity=capacity;
heap->size=0;
heap->arr= (int*)malloc(capacity * sizeof(int));
return heap;
}

void insert(Heap* heap,int x){
if(heap->size==heap->capacity){
    printf("heap overflow");
}
heap->size++;
int i=heap->size-1;
heap->arr[i]=x;
while (i!= 0 && heap->arr[(i - 1) / 2] > heap->arr[i]) {
        swap(&heap->arr[i], &heap->arr[(i - 1) / 2]);
        i = (i - 1) / 2;
    }
}

void Heapify(Heap* heap,int i){
int lc=2*i+1;
int rc=2*i+2;
int min=i;
if(lc<heap->size && heap->arr[lc]<heap->arr[min]){
    min=lc;
}
if(rc<heap->size && heap->arr[rc]<heap->arr[min]){
    min=rc;
}
if(min!=i){
    swap(&heap->arr[i],&heap->arr[min]);
    Heapify(heap,min);
}
}

void HeapifyAll(Heap* heap){
    int n=heap->size-1;
    for(int i=(n-1)/2;i>=0;i--){
        Heapify(heap,i);
    }
}

void deleteKey(Heap* heap, int index)
{
    if (index >= heap->size) {
        printf("Invalid index\n");
        return;
    }
    if (index == heap->size - 1) {
        heap->size--;
        return;
    }
    heap->arr[index] = heap->arr[heap->size - 1];
    heap->size--;
    Heapify(heap, index);
}

void delmin(Heap* heap){
    heap->arr[0]=heap->arr[heap->size-1];
    heap->size--;
    Heapify(heap,0);
}

int main(){

Heap* heap=createheap(100);
int n;
int k;
scanf("%d%d",&n,&k);
int arr1[n];
for(int i=0;i<n;i++){
  scanf("%d",&arr1[i]);
}

for(int i=0;i<k;i++){
    insert(heap,arr1[i]);
}

for(int i=k;i<=n-1;i++){
    if(arr1[i]<heap->arr[0])continue;
    else{
        insert(heap,arr1[i]);
        HeapifyAll(heap);
        delmin(heap);
    }
}

for(int i=0;i<k;i++){
    printf("%d ",heap->arr[i]);
}





    return 0;
}