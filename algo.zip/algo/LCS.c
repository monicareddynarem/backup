#include<stdio.h>
void LCS(int m,int n,char X[],char Y[]){
    int t[m+1][n+1];
    for(int i=0;i<=m;i++){
        for(int j=0;j<=n;j++){
            if(i==0||j==0)t[i][j]=0;
            else if(X[i]==Y[j]){
                t[i][j]=1+t[i-1][j-1];}
            else t[i][j]=max(t[i-1][j],t[i][j-1]);
        }
    }
}
int main(){




    return 0;
}