#include<stdio.h>
#include<malloc.h>

void swap(int* a,int* b){
    int temp=*a;
    *a=*b;
    *b=temp;
}

//priority queues
//list implementation
//each node has a priority,less value of prty,more priority
typedef struct node{
    int prty;
    struct node* next;
}node;

node* createNode(int p){
node* temp=(node*)malloc(sizeof(node));
temp->prty=p;
temp->next=NULL;
return temp;
}

int isempty(node* head){
    if(head==NULL)return 1;
    return 0;
}

//head is max priority(min element)
int getMin(node* head){
    if(isempty(head)){
    printf("empty priority queue");
    exit(0);
}
return head->prty;
}

//remove the maximum priority el(min element)
node* pop(node* head){
    if(isempty(head)){
        printf("empty priority queue");
        exit(0);
    }
    node* temp=head;
    head=head->next;
    free(temp);
    return head;
}

node* push(node* head,int newNum){
    node* n=createNode(newNum);
    if(head->prty > newNum){
        n->next=head;
        return n;
    }
    else{
        node* start=head;
        node* startprev=head;
      while(newNum > start->prty){
        if(start->next!=NULL){
            startprev=start;
            start=start->next;
        }
        else{
            start->next=n;
            return head;
        }
      }
      n->next=startprev->next;
      startprev->next=n;
      return head;
    }
}

//heaps:binary tree with certain properties
//min heap:each node's key is less than or equal to its children(root is the min)
//max heap:each node's key is greater than or equal to its children(root is the max)
//heap is a complete binary tree,all levels filled except last,last level as left as possible
//consider array with values from index 1(0 is not seen)
//node at index i:left child index-2i,right child index-2i+1

/*min heap*///can be visualised as complete binary tree
#define capacity 10
int size=0;
//helper functions to return indices
int Root(){
return 1;
}
int Parent(int n){
    return n/2;
}
int leftChild(int n){
    return 2*n;
}
int rightChild(int n){
    return (2*n)+1;
}
//for node testing
bool hasParent(int n){
    return n!=Root();//if index=1,i.e,n=1 its a root so no parent
}
bool IsNode(int n){
    return n<=size;
}

//getMin returns the node with highest priority/least value=min value in min heap=root
int getMin(int H[]){
    if(size==0){
        printf("empty priority queue");
        exit(0);
    }
    return H[Root()];//return H[1]
}

//insert an element to min heap
//to insert,first insert in last position and swap with parent if heap property not maintained
//func to shiftup the node to maintain heap property
void shiftUp(int H[],int n){
    while(hasParent(n) && (H[Parent(n)]>H[n])){
        swap(&H[Parent(n)], &H[n]);
        n=Parent(n);
    }
} 

void heap_push(int H[],int newNum){
    if(size==capacity){
        printf("priority queue full");
        exit(0);
    }
    H[size+1]=newNum;//insert at last;
    size++;
    shiftUp(H,size);
}

//pop an element from min heap
//first pop the root,since it is the least element->highest priority
//move last item to root and if heap is broken swap with smallest child
//continue going down till heap property maintained
void shiftDown(int H[],int n){
    while(IsNode(leftChild(n))){//if there is atleast one child
        int child=leftChild(n);
        //if right child exists and is less than left child;
        if(IsNode(rightChild(n)) && (H[rightChild(n)] < H[leftChild(n)]))
                child=rightChild(n);
//here child is the smallest of two childs if both exists
        if(H[n]>H[child])swap(&H[n], &H[child]);
        else break;
        n=child;
    }
}

void pop(int H[]){
    if(size==0){
        printf("Empty priority queue");
        exit(0);
    }
    H[Root()]=H[size];//H[1](root) is replaced with last element
    size--;//last element eliminated
    shiftDown(H,Root());
}

void buildheap(int arr[],int H,int n){
    for(int i=0;i<n;i++){
        H[i+1]=arr[i];
    }
    size=n;//size of H is size of arr
    for(int i=size/2;i>=1;i--)shiftDown(H,i);
}


//heapsort

int main(){
int H[capacity+1];//+1 since we are starting from index 1
}