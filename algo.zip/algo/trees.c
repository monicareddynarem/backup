#include<stdio.h>
#include<malloc.h>

int max(int a,int b){
    if(a>b)return a;
    return b;
}
typedef struct node{
    int data;
    struct node* left;
    struct node* right;
}Node;

//creating a new node and assigning it to a pointer
Node* newNode(int value){
Node* n=(Node*)malloc(sizeof(Node));
n->data=value;
n->left=NULL;
n->right=NULL;
return n;
}

//printing preorder sequence
void PreOrder(Node* root){
    if(root!=NULL){
        printf("%d ",root->data);
        PreOrder(root->left);
        PreOrder(root->right);
    }
    return;
}

//printing postorder sequence
void PostOrder(Node* root){
    if(root!=NULL){
        PostOrder(root->left);
        PostOrder(root->right);
        printf("%d ",root->data);
    }
    return;
}

//printing inorder sequence
void InOrder(Node* root){
    if(root!=NULL){
        InOrder(root->left);
        printf("%d ",root->data);
        InOrder(root->right);
    }
    return;
}

//check if a tree is a BST or not
int isBST(Node* root){  
    static Node* prev=NULL;
    if(root!=NULL){
       if(!isBST(root->left))return 0;
       if(prev!=NULL && root->data <= prev->data)return 0;
       prev=root;
       return isBST(root->right);
    }
 return 1;
}

//search for a key in a bst/return a pointer to that key, there is an iterative approach too
Node* search(Node* root, int key){
    if(root==NULL)return NULL;
    if(key==root->data)return root;
    else if(key > root->data)return search(root->right,key);
    else return search(root->left,key);
}


//inserting an element in a bst
Node* insert(Node* root,int key){
if(root==NULL)return newNode(key);   //create a new node and assign it to root
if(key < root->data){ root->left=insert(root->left,key);}
else if(key > root->data){ root->right=insert(root->right,key);}
else printf("key is already there");
return root;
}

//minvalue of a tree
Node* minValue(Node* node){
    Node* current=node;
    while(current->left !=NULL){
        current=current->left;
    }
    return current;
}

//maxvalue of a tree
Node* maxValue(Node* node){
    Node* current=node;
    while(current->right!=NULL){
        current=current->right;
    }
    return current;
}

//inorder successor 
Node* inOrderSuc(Node* root,Node* n){
    if(n->right !=NULL)return minValue(n->right);
    Node* succ=NULL;

    while(root!=NULL){
        if(n->data < root->data){
            succ=root;
            root=root->left;
        }
        else if(n->data > root->data)
            root=root->right;
        else break;
    }
    return succ;
}

//inorder predecessor
Node* inOrderPre(Node* root,Node* n){
    if(n->left!=NULL)return maxValue(n->left);
    Node* Pre=NULL;

    while(root!=NULL){
        if(n->data > root->data){
            Pre=root;
            root=root->right;
        }
        else if(n->data < root->data) 
            root=root->left;
        else break;
    }
    return Pre;
}


// deleting a node;
Node* delNode(Node* root,int key){
if(root==NULL)return NULL;
if(key < root->data)root->left=delNode(root->left,key);
else if(key > root->data)root->right=delNode(root->right,key);
else{
     if(root->left==NULL){
    Node* temp=root->right;
    free(root);
    return temp;
   }
    else if(root->right==NULL){
    Node* temp=root->left;
    free(root);  
    return temp;
   }
    else{
    Node* temp=minValue(root->right);
    root->data=temp->data;
    root->right=delNode(root->right, temp->data);
   }
}
return root;
}


//print the tree
int height(Node* x){
if(x==NULL)return 0;
return 1+ max(height(x->left),height(x->right));}

void printcurrentlevel(Node* root,int level){
    if(root==NULL)return;
    if(level==1)printf("%d ",root->data);
    else if(level>1){
        printcurrentlevel(root->left,level-1);
        printcurrentlevel(root->right,level-1);
    }
}
void printlevelorder(Node* root){
    int h=height(root);
    for(int i=1;i<=h;i++){
        printcurrentlevel(root,i);
        printf("\n");
    }
}

//mirror image
Node* mirror(Node* root){
if(root==NULL)return NULL;
Node* temp=root->right;
root->right=root->left;
root->left=temp;
}
int main(){

// Node* root=NULL;
// root=insert(root,5);
// root=insert(root,3);
// root=insert(root,6);
// root=insert(root,1);
// root=insert(root,4);
// root=insert(root,9);
// root=insert(root,2);
// root=insert(root,8);
// // root=insert(root,7);
// // root=insert(root,10);

// printlevelorder(root);

// root=mirror(root);
// printlevelorder(root);
return 0;
}