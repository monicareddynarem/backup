#print("string to print") print(a+b)
#print("my name is:",age,"kebaekga")-different partrs to be printed are separated by ,
'''
DATATYPES:string,integer,float,boolean(True,False),none
logical operator:not,and,or

id(a)=address of a variable named a
b=a then id(b) will be same as id(a)
''''''

BITWISE OPERATORS:
|-or
&-and
~negation
^XOR(0 when both are same,1 when both are different)
''''''

INPUT:input("text to be printed while asking")
newvar=input("text")
default type of input is string,changes any type to string
to change type: int(input("text"));float(input("text"))
''''''

STRINGS:(immutable)
concatenation:"string1"+"string2"
length of string:len(str)
indexing:0,1,2...//only access but cannot change
        cannot change string value with index,s[4]=a(not allowed)
slicing:str[start_idx:end_idx]:start_idx included,end_idx not included
        str[:k]-from starting to k idx(k not included)
        str[k:]-from k(included) to ending indx
    NEGATIVE IDX:last elemnt:-1,second last:-2...(exists only for slicing)
str.endswith("stringend")-if str ends with "stringend" then it returns true else false
str.capitalize()-capitalizes first char,does not change original str 
                 str=str.capitalize() changes original string
str.replace("old","new")-replaces all occurences of old to new
str.find("word")-returns 1st index of first occurence
str.count("value")-returns number of occurences of the value
''''''

CONDITIONAL STATEMENTS:
if(condition):statement 1
elif(condition):st2
else:st3
''''''

LIST:(mutable)
list1=[value1,value2,...]
list[0]=value1,list[1]=value2...
list[0]=newvalue(allowed)
len(list)=length of list

LIST SLICING: list[start_idx:end_idx]=[vstart,...vend-1]
              endidx not included,negative index also allowed

LIST METHODS:
list.append(4)-adds value(4) at the end of list
list.sort()-sorts list in ascending order
list.sort(reverse=True)-sorts in descending order
list.reverse()-reverses list
list.insert(idx,el)-insert el at idx
list.remove(value)-removes first occurence of value
list.pop(idx)-removes element at idx 
list1==list2(allowed for checking conditions)

TUPLES:immutable sequence
tuple=(val1,val2,...)

TUPLE METHODS:
slicing
tup.index(el)-returns index of first occurence of el
tup.count(el)-number of occurences of el
''''''

EXTRA:
import math-imports all math functions
      use as math.sqrt
import math as m-uses as m.sqrt,m.floor,...(alias name)
to use specific functions only
 from math import sqrt,pow,etc
     use as pow(a,b)[no need to specify math.pow]

swap two numbers:
a,b=b,a[ordered assignment/swapping]
''''''

LOOPS:
break:exits loops
continue:exits current iteration,goes to next iteration
pass: to be written later(general/not only in loops)
#WHILE LOOP:
    while condition:
        some work

#FOR loops:
  for el in list:
      some work
  (optional-work to do after loop,else excecutes only if complete loop runs(no breaks))
  else:
      somework

range(start?,stop,step?):
   stop is not included
   (default)starts at 0,step=1,stops before specified number
range(5=stop):0,1,2,3,4
range(2=start,10=stop)
range(2=start,10=stop,2=step)
'''

'''
DICTIONARIES:
name={
"key":value,
"key2":value2.
}

access-> name["key"]->if not present->gives error

methods: name.items()
name.keys()
name.values()
marks.update({key:value,...})
marks.get("key")->if key not present it gives none,
'''
#arrays
'''
FUNCTIONS:
print (end=" "),print(end="\n")
def func_name(param1,param2..):
        some work
     return val

func(a=val1,b=val2)-if no parameters are passed val1,val2 are taken as default values
a function can return two values,int that case result1,result2=func(parameters)//order of returning and order of assigning should be same
while calling the function if we dont know the order of parameters:
        func_name(param1=value1,param2=value2,....)
variable length parameter:
       func(a,*b):
    call:func(v1,v2,v3,v4,...)
    b=(v1,v2,v3,v...)stored as tuple
kwargs:keyworded variable length arguments
   func(name, **data):
   call as fun(val1, age=val2, place=val3,...) //data is a dictionary

RECURSION:recursion same as c
parameters are pass by value,lists are pass by reference(same as c)

Keywords:global a-to change a local variable to global variable
         x=globals()['a'] refers to a

lambda function:
f=lambda a:a*a   f(5) returns 5*5

FILTER MAP REDUCE
#FILTER-filter using a given condition
evens=list(filter(condition,input_listname))
      if condition is true,takes into list
      we want the output in a list format

#MAP-change every value
doubles=list(map(operation,input_listname))

#REDUCE-import: from functools import reduce
       sums=reduce(operation,listname)
reduces the list to a singke value,given an operation

#DECORATORS:
 modify functions without changing original
 newfunc(func):
   work
   return func

//assigning a func to another func is valid func1=func2 valid
'''

#special variable __name__
#file i/o

'''
OOPS:
CLASS AND OBJECT:
__inut__ function:(constructor)called at the time of object creation
parametrized and non parameterized constructuors
METHODS:functions inside class
'''

#creating object
class Student:
    
    #class attributes-same to all objects of this class
    name="abc"
    collegename="college"
    
    #a class only has one constructor
    #constructor __init__
    #default constructors
    def __init__(self):
        pass 

    #parameterized constructors
    #self is a default parameter-refers to the object being created-same as 'this' in cpp
    def __init__(self,fullname):
        self.name=fullname #object attributes-diffrent for each object og the class

    #methods
    def hello(self):
        print("hello",self.name)


    #static method-methos which dont use self-work at class self/can skip the word self
    @staticmethod
    def college():
        print("abc college")
    

class Account:
    def __init__(self,accno,accpass):
        self.accno=accno
        self.__accpass=accpass
#to make a variable private add __ infornt of it


#INHERITANCE 

class Car:
    def __init__(self,type):
        self.type=type

    @staticmethod
    def start():
        print("car started")

    @staticmethod
    def stop():
        print("car stopped")


class ToyotaCar(Car):
    def __init__(self,name,type):
        self.name=name
        super().__init__(type)
#super() method used to access parent from derived class


car1=ToyotaCar("fortuner")
car2=ToyotaCar("prius")
# s1=Student("abcdef")
# s2=Student("Monica")
# s1.hello()
# s2.hello()
# del s1.name#deletes the name of s1
# del s1#deletes the student s1


class Person:
    name="anonymus"

    def changeName(self,name):
        self.name=name#changes only attribute value of the object
        Person.name="xyz"#1st way to chnage the class attribute,after this for any person.name="xyz"
        self.__class__.name="abc"#2nd way to change class attribute

    @classmethod#3rd way to change class attributes
    def changeName(cls,name):
        cls.name=name

'''
static methods-no use of any attributes/arguments
class methods-use class as arguments
instance methods-use self as argument-object as arg'''

p1=Person()
p1.changeName("Monica")#p1.name=Monica
#but Person.name=anonymus