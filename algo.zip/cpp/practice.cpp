#include<iostream>
#include<cstring>
#include "myfunc.h"
using namespace std;

typedef struct _String{
    char* str;
}String;

int main(){
//     int a=10,&b=a;
// a,b point to the same address
//     cout<<a<<"  "<<b;
String fName,lName,name;
fName.str=strdup("Partha ");
lName.str=strdup("Das");
name.str=(char*)malloc(strlen(fName.str)+strlen(lName.str)+1);
strcpy(name.str,fName.str);
strcat(name.str,lName.str);
//strdup("string") returns a pointer to a duplicate of the string

    return 0;
    }