#include<bits/stdc++.h>
using namespace std;

//algorithms,containers,iterators,functions-stl


/*containers*/
//pairs
void pairsexplain(){
pair<int,int>p={1,3};
//the first int is datatype of first value,and second the datatype of second value
cout<<p.first<<p.second;
//p.first access the first value in the pair,p.second access the second value
//we can also create pair of pairs
pair<int,pair<int,int>>q={2,{5,7}};
//q.first=2,q.second.first=5,q.second.second=7
//create array of pairs
pair<int,int>arr[]={{1,2},{3,4},{5,6}};
//arr[1].second=4,arr[0].first=1
}


void vectorsexplain(){
//similar to an array but size can be changed,contiguous memory allocation
//declarations
vector<int>v;//v is a vector initialized empty v={}
v.push_back(1);//adds 1 to the vector v={1}
v.emplace_back(2);//adds 2 to the vector v={1,2};
vector<pair<int,int>>vec;//vector of pairs
vec.push_back({1,2});//pushback({1,2})requires a pair in input
vec.emplace_back(1,2);//emplace back requries just 2 values without{},better than pushback
vector<int>v1(5,100);//vector v1 of size 5, each value 100
vector<int>v2(5);//vector v2 of size 5,each of value 0 or garbage value
vector<int>v3(v1);//v1 is copied into v3, v3 is same as/copy of v1

vector<int>vnew={20,10,50,3,7};
//iterator declaration,it is the name of iterator
//it=v.begin->it points to the first element of the vector vec[0];
vector<int>::iterator it=vnew.begin();
it++;//it pointer points to the next elmt in vector,vec[1]
//to access value use *(it);

vector<int>::iterator it1=vnew.end();
//v.end() points to the address after the last element in the vector
//v.rend() points to before the first element
//v.rbegin() points to last element of the vector
//the iterator also works in a reverse way,basicallt the whole vector is reversed and opertions are applied
//v[i]=v.at(i)
//v.back() is the last element of the vector
//to print hte elemts of vector
for(vector<int>::iterator it=vnew.begin(); it!=v.end(); it++){
    cout<<*(it);
}//here auto means vector<int>::iterator
for(auto it=v.begin(); it!=vnew.end(); it++){
    cout<<*(it);
}
for(auto it:v){
    cout<<it;//here auto means int
}
//auto assigns the data type automatically

//deletion of elements in vector
//take example v={10,40,50,20,30}
v.erase(v.begin()+1);//erases 40, v={10,50,20,30}
//give the iterator address to the func v.erase to delete single element
v.erase(v.begin()+1,v.begin()+3);
//give range of iterators [start,end)(deletes v.begin+1,v.begin+2)
//the second iterator here is the iter after the last elemt to be deleted
//this gives v={10,20,30}

//insert function
vector<int>newv(2,100);//consider this vector newv={100,100}
newv.insert(newv.begin(),300);//inserts 300 at the v.begin() position, newv={300,100,100}
newv.insert(newv.begin()+1,2,10);//inserts 10 two times starting form begin+1 position
//newv={300,10,10,100,100}
vector<int>copy(2,50);//copy={50,50}
newv.insert(v.begin(),copy.begin(),copy.end());
//selects all elemnts in the given range from another vector,and places them then in newv starting from the given postion
//copy.begin() starting pos, copy.end() is after last elemt,all elmts in this range copied to newv
cout<<newv.size();//size of the vector
newv.pop_back();//pop_back removes the last elemt of the vector
newv.swap(copy);//swaps both vectors
newv.clear();//erases the entire vector
cout<<v.empty();//returns true if vector has no element and false if it has atleast 1 elements
//v.front() gives the firstr elment,v.back() gives last elemetnt
//v.data() returns pointer to first elmt of arry used
//emplace(position,value) same as insert

}


void list_explain(){
//same as vectors but gives front operations as well
//doubly linked list,non contiguous memory
list<int>ls;//ls={}
ls.push_back(2);//ls={2}
ls.emplace_back(4);//ls={2,4}
ls.push_front(5);//ls={5,2,4}
ls.emplace_front(3);//ls={3,5,2,4}
//other func same as vector:v.begin,v.end,rend,rbegin,swap,insert,size,etc
//front(),back(),pop_front().pop_back
//remove(value) removes all elemtns equal to that value
//reverse(ls) reverses the list
//sort() sorts the list in increasing order
//list_unique removes all duplicate elemts
}

void explaindeque(){
//same as list but "may" not be contiguous memory
//doubly ended queue
deque<int>dq;
//same functions as vectors:push_back,push_front,emplace_back,emplace_front,etc
//insert(value),inserts value and returns pointer to first of newly inserted elmets

}

void explainstack(){
//last in first out
stack<int>st;
st.push(1);//st={1}
st.push(2);//st={2,1},first element is the top
st.push(3);
st.push(3);//st={3,3,2,1}
cout<<st.top();//prints 3,cannot do st[i]
st.pop();//removes top most elmt st={3,2,1}
st.size();//returnssize of stack
st.empty();//returns 1 if st has 0 elements
stack<int>s1,s2;
s1.swap(s2);//swaps two stacks
s1.emplace(5);//inserts 5 at the top of stack,same as push
}

void explainqueue(){
//first in first out
queue<int>q;
q.push(1);//q={1}
q.push(2);//q={1,2},emplace is same as push
q.push(4);//q={1,2,4}
q.back()+=5;//q.back() is the last elemt of the queue,q.back() here becomes 9
//q.front()=1,q={1,2,9}
q.pop();//q={2,9},first in is 1,pop removes firstr in elmt
//q.front()=2
//size(),swap(),empty() same as stack
}



void explain_priority_queue(){
//the largest number stays on top,same as max heap
priority_queue<int>pq;
pq.push(5);//pq={5}
pq.push(2);//pq={5,2}
pq.push(8);//pq={8,5,2}
pq.push(10);//pa={10,8,5,2}

cout<<pq.top();//10
pq.pop();//pq={8,5,2}removes top element
cout<<pq.top();//8
//size,swap,empty functions are same


//min heap
//syntax is different
priority_queue<int,vector<int>, greater<int>>pq;
pq.push(5);//pq={5}
pq.push(2);//pq={2,5}
pq.push(8);//pq={2,5,8}
pq.push(10);//pq={2,5,8,10}
}


void explainset(){
//sorted order and unique
set<int>st;
st.insert(1);//st={1}
st.emplace(2);//st={1,2}
st.insert(2);//st={1,2}
st.emplace(3);//st={1,2,3}
st.insert(4);//st={1,2,3,4}
//functions used for vectors can be used
auto it=st.find(3);//returns an iterator which points to 3
//if elemt is not in the set st.find() returns an iterator after last element of set
st.erase(4);//deletes 4
int cnt=st.count(1);//if it exists it returns 1 else 0
//erase can take value or iterator to that element or range of iterators [first,last)

auto it=st.lower_bound(2);
auto it=st.upper_bound(3);

/*lower bound(el)-if the el is present in the set, then it returns the pointer to the element(first occurence),
                  else it returns pointer to the immediately next greater element in the set
  upper bound(el)-returns pointer to the element immediately greater than the el(whether the el,is present or not)
*/
}

void explainmultiset(){
    multiset<int>ms;
//same as set,but contains duplicate values also(only sorted)
//sorted but not unique
//insert,erase(erases all instances),count same as sets
//ms.find(1) returns an iterator to the first occurence of 1
}

void unorderedset(){
//only unique(may not be sorted)
unordered_set<int>us;
//except lower bound and upper bound all func are same
}


void explainmap(){
map<int,int>mpp;
//1st value is key-unique, second value may not be unique
//key and values can be of any datatype
//it stores unique keys in sorted order
mpp[1]=2;//this means mpp stores {1,2} inside, 1 is the key, 2 is the value
mpp.emplace(3,1);//mpp=[{1,2},{3,1}]
mpp.insert({2,4});//mpp=[{1,2},{2,4},{3,1}]
//it stores pairs {key,value}
//to access values make an iter
for(auto it:mpp){
    cout<<it.first<<it.second;//here it points to a pair
}

auto it=mpp.find(3);//returns a pointer to a pair which has key 3
//to access this: *(it).second
//if key not there in map, .find()returns a pointer to after last
auto it=mpp.upper_bound(2);
auto it=mpp.lower_bound(1);
//upperbound,lowerbound,size,swap,erase are same
}


void explainmultimap(){
    //everything same as map,but we can store duplicate keys
    //mpp[key] cannot be used here
    //sorted keys but not unique
}

void unorderedmap(){
    //unique keys but not in sorted order
}


//extra methods and functions
bool comp(pair<int,int>p1,pair<int,int>p2){
if(p1.second < p2.second)return true;
if(p1.second > p2.second)return false;
if(p1.first > p2.first)return true;
return false;//take two elemts and write for which condition it will be valid or not
}

void extra(int a[],int n){
sort(a,a+n);//sorts array from index a to a+n-1,[a,a+n) in ASCENDING ORDER
vector<int>v;
sort(v.begin(),v.end());
//to sort in descending order, add greater<int>()
sort(a,a+n, greater<int>());
//for sorting in own ways,example
pair<int,int>arr[]={{1,2},{2,1},{4,1}};
//sort arr according to second elemt,if same sort first el in descng order
sort(a,a+n,comp);//comp is a self made comparator

int num=7;
int cnt=__builtin_popcount(num);//returns the number of 1's in binary of num
long long num=12355364249;
int cnt=__builtin_popcountll(num);//returns number of 1's in binary

string s="123";
do{
    cout<<s;//123 132 213 231 312 321
}while(next_permutation(s.begin(),s.end()));//prints all permutations in dixtionary order
//if s was 231;it would print only from 231: 231 312 321

auto it1=max_element(a,a+n);//returns a pointer to the max element in array
//to access the elemt use *, same with min_element

}




int main(){



    return 0;
}