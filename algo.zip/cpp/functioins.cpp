#include<iostream>
using namespace std;

#include "myfunc.h"

void printname(int a,int b){
    cout<<"a="<<a;
    cout<<"b="<<b;
}

void printclass(char a){
    cout<<"this class is printclass="<<a;
}