#include<bits/stdc++.h>
using namespace std;

//OOPS
/*access modifiers:
private:data&methods accessible inside class(default)
public: accessible to everyone
protected: accessible inside class & to its derived class
*/
class Teacher{
    //properties
private:
     double salary;
public:
     string name;
     string dept;
     string subject;

//non parameterized constructor
    Teacher(){//this function is called a constructor
        dept="Computer Science";//automatically assigns cse to objects at the time of creation
    }

//parameterized constructor
//since name in class and name in arguments are same,its confusing so we use this->name fot the class's name
   Teacher(string name,string dept,string subject,double salary){
    this->name=name;
    this->dept=dept;
    this->subject=subject;
    this->salary=salary;
   }

//copy constructor:used to copy values of one object to other object
    Teacher(Teacher &orgObj){//pass by reference
    this->name=orgObj.name;
    this->dept=orgObj.dept;
    this->subject=orgObj.subject;
    this->salary=orgObj.salary;
    }



//methods/member functions
void changeDept(string newDept){
    dept=newDept;
}
void setSalary(double s){
    salary=s;
}
double getSalary(){
    return salary;
}
void getInfo(){
    cout<<name;
    cout<<subject;
    cout<<dept;
    cout<<salary;
}
};

//CONSTRUCTOR:used for intialisation: same name as class,memory allocation happens when constructor is called
//always public since it has to go to main
//one class can have many constructors, constructors should have different parameters,
//compiler identifies automatically which constructor should be called based on parameters
//"this" is a special pointer used to specify the keys of that class this automatically points to the class
//this->prop means *(this).prop
//copy constructor used to copy properties of one object to another
//copy constructor:copy is of two types
/*shallow copy:only copies values of one object to other object(default)
  |->when the key in the class does not have dynamic memory allocation,there is no issue in copying
  |->when there is DMA there is a problem
deep copy:dynamically allocated memory is also copied
|->new double:a pointer pointing to a double variable
*/
/*DESTRUCTOR
opposite of constructor(deallocates memory)(default after end of main it deallocates memory)
new datatype-allocates memory of this datatype to a pointer
delete ptr-does not delete ptr,deletes the memory to which the ptr is pointing
same name as class/constructor but with ~ sign
*/
/*INHERITANCE:properties and member functions of base class are passed on to derived class
used for code reusability
base class constructor is called first then derived class constructor is called
destructor is opposite:derived class called first,base class called later
>if base class is private it cannot be inherited
>if base class is public the mode of inheritance is same as that of derived class
>if base class is protected(used just for inheritance):
               if derived class-private:mode-private
               else:mode-protected
TYPES OF INHERITANCE:
single inheritance:parent->child
multi-level inheritance: parent->parent->
multiple inheritance: two or more parents->child
hierarchial inheritance:single parent multiple children
hybrid inheritance: mixed of all/any types
*/
/*POLYMORPHISM:ability of objects to take different forms depending on context
>compile time polym.-constructor overloading(making many constructor functions)
                    -function overloading(same name of function but different parameters)
                     compiler automatically identifies which fucntion to call based on parameters
                    -operator overloading
(overloading)-same class function same name//(overriding)-inheritance;child class has more priority
>run time polym:-function overriding
                -virtual functions:is a member function that u expect to be redefined in derived class
                  dynamic in nature,keyword virtual inside base class  and always written inside base class, overriden in child class
                  is called during runtime
*/
/*ABSTRACTION:hiding all unnecessary parts and showing only important parts
              access modifiers one of the way to implement
Abstract classes:only created for inheritance(used as base class)
                -cannot create objects from this class(cannot be instantiated,instance-object)

a funcion which has virtual keyword-pure virtual function
a class which has a "only" pure virtual function automatically becomes an abstract class               
*/
/*STATIC KEYWORD
static variable:created and initialised only once(initialising again will not change the value of variable )
                in class,variable shared by all the objects of the class
static object:if an object is created static clas obj,then in will persist for the lifetime of the program,
              it will end after the end of all functions(main)



*/

class Student1{
    public:
        string name;
        double* cgpaPtr;

    Student1(string name,double cgpa){
        this->name=name;
        cgpaPtr=new double;
        *cgpaPtr=cgpa;
    }

//copy constructor
//shallow copy
//we are making two pointers pointing to the same address:one's change affects the info of other
    // Student(Student &obj){
    //     this->name=obj.name;
    //     this->cgpaPtr=obj.cgpaPtr;
    // }
//deep copy
//we are creating a new memory and copying the value in it
    Student1(Student1 &obj){
        this->name=obj.name;
        cgpaPtr=new double;
        *cgpaPtr=*obj.cgpaPtr;
    }

//Destructor//executes for each object after main function complettion
    ~Student1(){
        delete cgpaPtr;//frees the memory(default is also called)
    }

    void getInfo(){
        cout<<"name:"<<name<<endl;
        cout<<"cgpa:"<<*cgpaPtr<<endl;
    }
};

/*INHERITANCE*/
//single level:person-student
class Person{
public:
      string name;
      int age;

    Person(string name,int age){
        this->name=name;
        this->age=age;
    }

};

class Student: public Person{
    //name,age,roll no(age,name already defined in person->no need to define again)
public:
      int rollno;

//parameterized constructor call
      Student(string name,int age,int rollno) : Person(name,age){
            this->rollno=rollno;
      }

      void getInfo(){
        cout<<"name:"<<name<<endl;
        cout<<"age:"<<age<<endl;
        cout<<"rollno:"<<rollno<<endl;
      }
};


//multiple inheritance:multiple parents single child
class Class1{
public:
    string name;
    int rollno;
};

class Class2{
public:
    string subject;
    double salary;
};

//class 3 inherits both class1 and class2(all parents separated by commas)
class Class3: public Class1,public Class2 {
public:
     string researcharea;
};


/*POLYMORPHISM*/
//exmaple of runtime polym. function overiding
//child.show()prints child class(overrides parent show function)
//parent.show()prints parent class
//virtual function hello:child.hello prints hello from child(child hello overrides paretn hello)
class Parent{
public:
     void show(){
        cout<<"Parent class";
     }

     virtual void hello(){
        cout<<"hello from parent";
     }
};

class Child:public Parent{
public:
     void show(){
        cout<<"child class";
     }

     void hello(){
        cout<<"hello from child";
     }
};



int main(){
// Teacher t1;here t1 is an object,constructor call, non parameterized example
// Teacher t1("Monica","CSE","electronics",25000);//parameterized: assigns the parameters as values
// Teacher t2(t1);//default copy constructor
Parent p1;
    return 0;
}