void printname(int a,int b);
void printclass(char a);