const student={
    fullName: "Monica",
    marks:94.4,
    printmarks:function(){
        console.log("marks=",marks);
    }}