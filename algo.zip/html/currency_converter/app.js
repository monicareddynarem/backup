const BASE_URL="https://v6.exchangerate-api.com/v6/df4e3e54f6b854ea245bb191/pair/EUR/GBP";

const dropdowns=document.querySelectorAll(".dropdown select");
const btn=document.querySelector("form button");
const fromCurr=document.querySelector(".from select");
const toCurr=document.querySelector(".to select");
const msg=document.querySelector(".msg");

for(let select of dropdowns){
    for(Currcode in countryList){
        let newoption=document.createElement("option");
        newoption.innerText=Currcode;
        newoption.value=Currcode;
        if(select.name==="from" && Currcode==="USD"){
            newoption.selected=true;
        }else if(select.name==="to" && Currcode==="INR"){
            newoption.selected=true;
        }
        select.append(newoption);
    }

    select.addEventListener("change",(event)=>{
        updateFlag(event.target);
    })
}


const updateFlag=(element)=>{
let Currcode=element.value;
let countryCode=countryList[Currcode];
let newsrc=`https://flagsapi.com/${countryCode}/flat/64.png`;
let img=element.parentElement.querySelector("img");
img.src=newsrc;
};

btn.addEventListener("click",async (evt)=>{
    evt.preventDefault();
    let amount=document.querySelector(".amount input");
    let amtVal=amount.value;
  
    const URL=`https://v6.exchangerate-api.com/v6/df4e3e54f6b854ea245bb191/pair/${fromCurr.value}/${toCurr.value}`;
    let response=await fetch(URL);
    let data=await response.json();
    let rate=data.conversion_rate;
    let finalVal=rate*amtVal;
    msg.innerText=`${amtVal}${fromCurr.value}=${finalVal}${toCurr.value}`;
})