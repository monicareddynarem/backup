//console.log("text"); is used to print text,\n-next line,\t-tab(length 1)
//separate console.log statements print in next lines
//js is case sensitive
// console.log("print text");
//no need to mention datatypes 
/*let:variable cannot be redeclared,but can be updated,block scope
  var:can be redeclared,updated,global scope
  const:cannot be redeclared,cannot be updated,block scope(need to be assigned a value at the time of declaration)
  */
// a=null;
// b=undefined;
/*object(similar to structure in c):
const name={
name: value1,
class: value2,
so on
};
 */
//a**b=a^b
//a==b(checks only value//js converts string numbers to numbers internally)
//a===b(checks both value and datatype)
//to print values from variables console.log("text",a+b,"text 2",and so on);
/*if/else/else if statement*/
/*if(condition){
       code/methods;
       }else{
       other code/methods;
      }
//ternary operator: a ? b : c (if a is true b is executed,else c is)
//switch statement:(if one statement is true all the next statements are executed,to avoid this break is used)
switch(expr){
case 'value1 of expr':
         code;
case 'value2':
         code2;(and so on)
default:
     default code for all cases     }

*/
//alert("text");gives a pop up message on the window
//variable=prompt("text"):gives a pop up as well a taked input from user,which we assign to a variable
/*LOOPS:
a)for(let i=1;i<n;i++){
code; } 
b)while(condition){
code;}
c)do{
code;
}while(condition);
d)for-of:on strings and arrays,iterates on each value of the array
 for(let i of string){
 code;}
e)for-in:arrays and objects//i iterates on the "key"s of object(name,class,age..)
 for(let i in student(object)){
 code;
 }
*/
/*STRINGS(immutable)
str.length;str[0],str[1]...
template literal:
console.log("the cost of",var1,"is",var2);//alternate method
let output='the cost of ${var1/expr} is ${var2/expr};
console.log(output);
BUILT IN FUNCTIONS
str.toUpperCase() assign to a new string
str.toLowerCase()
str.trim()//removes whitespaces at the starting and ending of the string,in between ones are not afected
str.slice(start,end);returns part of the string,end is not inclusive
str1.concat(str2)//joins str2 with str1=>str1+str2
str.replace(searchval,newval)//can replace one string with another string inside the given string
str.charAt(idx)
*/

/*ARRAYS-mutable
arr.length
loop:for-of/for/while/do while
methods:
push():add to end//length changes+1//changes in original array
pop():removes last elemt//length changes -1//original array
toString():changes array to string//original array does not change
arr1.Concat(arr2,arr3,..)//join multiple arrays and returns result
unshift():push from the start of the array
shift():pop from the start of the 
slice(startidx,endidx):does not change original array,endidx not inclusive
splice(add,remove,replace):splice(startidx,delcount,newEl1,newEl2...);
*/
/*FUNCTIONS
function fnname(parameter1,2,3..){
code;
}
arrow fn:assign this to a variable
const fn_name=(parameter1 , p2,p3..)=>{
  code;
  }
call using fn_name(p1,p2,p3...)
*/
/*forEach loop in arrays
arr.forEach(callBackFunction)//callbackfn:a function passed as an argument to another fn
  |->this means for each value in the array the call backfn is called
  |->changes in same array

arr.map(callbackfn(value,index,array))//same as for each but returns a new array

arr.filter(callbackfn which returns true or false for some values of arr)
    |->returns a new array
    |->if the condition in callbackfn becomes true for a value of arr,it is included in the new arr else it is not

arr.reduce(callbackfn which returns a single value)returns a single value 
*/

/*DOM(to access html through js)-to use dynamic manipulation
console.log(window.document)prints the html file linked
console.dir(window.document)prints the properties of the document/html file
dir prints properties,window is global(no need to write)
childNodes:nodes under other nodes
console.dir(document.body.childNodes[1]):prints the first elemt in the body tag
if<script src="link"> is written before body tag..body elements cannot be accesses
*/
/*selecting elements:
a)selection with ID:document.getElementById("Idvalue")
b)selection by class:document.getElementsByClassName("classname")//html collection similar to array
c)selection with tag:getElementsByTagName("tag name")//html collection similar to array
QUERY SELECTOR:
a)document.querySelector("#Id/.class/tag")//returns first element
  document.querySelectorAll("#Id/.class/tag")//returns all elements/nodelist
*/
//Properties(get/set)//we can change the values also
/* element.tagName returns the tag of the element(p/h1/button/...)
   element.innerText returns the text content of the element and all its children
   element.innerHTML returns the html content inside the element along with its tags 
   element.textContent shows text even for hidden elements
*/
/*to get attributes
element.getAttribute("attribute name") returns the attribute value 
element.setAttribute("attribute name",newvalue) updates the attribute value 
element.style returns the css for the element
in css background-color changes in js to backgroundColor
*/
/*create and add elements:
let el=document.createElement("element name");
node.append(el) adds at the end of node(inside);
node.prepend(el)adds at the start of node(inside);
node.before(el)adds before the node(outside);
node.after(el) adds after the node(outside);
let heading=document.querySelector("h2");

to remove/delete a node:
node.remove();

node.appendChild(el) adds the elemnet to the end of list of children of the node
node.removeChild(el) removes the el and returns the removed node(child)

classList(el) returns all the classes present in that elemt
*/

/*
let varname=num1;
number methods;string methods
->varname.toFixed(k);-->rounds off to k decimal places
->Number(string of a number)-converts the string to a number
->String(arg)-converts the arg to a string
->str.length-gives length of string
->str.includes(substring)-returns true or false
->str.startsWith(substring)
->str.endWith(substring)
->str.indexOf(substring,optional(point to start from))
->str.toLowerCase()/str.toUpperCase()-change all letters
->str.replace(substring,newvalue)->only chnages first occurence;replaceAll changes all occurences

array methhods:
->arr.indexOf(value)-returns index pf value in the array
->arr.push(value)-inserts at the last of array
->arr.unshift(value)-to add at the start
->.pop()-removes last value
->.shift()-to remove first el
->.splice(index1,index2)-removes these els
->for(const el of arr){
code}-to access evry el
->arr.map(function)-evaluates the function for each el in arr
->arr.filter(condition)-takes the values for which cond is true
->str.split(substring)-splits at these substring and returns the remaining as values of array
->arr.join(substring)-rev of split
->arr.toString()
->Math.random()-generates a number between [0,1)


arrow function:
(param1, param2,...)=>{
                       code;}
*/ 


/*EVENTS
event handler:the object on which the evnt is taking place
var.addEventListener("event name",function/task to do);
button events:focus(press tab),blur,click,mouseover,mouseout
var.removeEventListener()-removes the event;
->abort method to remove events
->onclick:can use var.onclick=()=>{};//but can be used only once:
         btn.onclick=fn; btn.onclick=fn2; does not execute two fns;
->the calling function for an event can take parameter e,and we can apply changes to the event handler
     itself using e.target->refers to el on which the event was initially fired
     e.currentTarget->used to access the el to which addeventlistener is attached
     -target is same when an event bubbles up
     -currentTarget identifies the element whose event handler we r currently running in the bubbling up scenario
->keydown event-called when we press a key on the keyboard-key is event.key
->events happen from the inner most el to outermost parent-bubbling
->to stop bubbling: event.stopPropagation() is used inside event handler function
  to get reverse of bubbling(largest tag->child el->sub child el):
        :add-{capture:true} as the last argument for add Event Listener
         
*/

/*OBJECTS-OOPS:
const objname={
     name:values1,
     age:value2,
     val2:function(){//val2 is the function name
     }
     val2(){//other way for function
     }
        }
objname obj1;
>obj1.name/obj1.age/obj1.val2(dot notation)
>obj1["name"]-used when the property name is stored in a variable
var="name";obj1.var(wrong),obj1[var] must be used
'this' word is used to refer to the self object inside the members
>we can create new members outside the object,by defining outside

*/

/* there is a default object- prototype inside every object that is created
to set prototype use __proto__
>object1{methods1}
>object2{methods2}
->if we set object2.__proto__=object1
we can use the methods and variables of object 1 in object2{same as inheritance in classes}

classes:

class MyClass{
funcname(){}

}
let objname=new classname
constructor()->creates custom constructor
this-is used to refer to self object
INHERITANCE:
class class1
class class2 extends class1->class1 is the parent of class2-inherited in class 2
>super(args)//calls parent's constructor-|->used to access parents methods from child
>super.parentmethod(args)               -|
*/


/*
async functions:
setTimeout(func,millisec(time in which to execute this))
Callback:a function which is passed as an argument to another function

let promise=new Promise((resolve,reject)=>{
  
  
  })

*/