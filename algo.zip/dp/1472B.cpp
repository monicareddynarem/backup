#include<iostream>
using namespace std;

int output(int arr[],int n){
int dp[n];
dp[0]=0;
int sum=0;
for(int i=0;i<n;i++){
sum+=arr[i];
}
 if(sum%2!=0)return 0;

int count1=0;
int count2=0;
if(arr[0]==1)count1++;
else count2++;

for(int i=1;i<n;i++){
    if(arr[i]==1)count1++;
    else count2++;

    if(dp[i-1]==1){
        dp[i]=0;
    }
    else{
       
    }
}

}


int main()
{
    
#ifndef ONLINE_JUDGE
freopen("input.txt", "r", stdin);
freopen("output.txt", "w", stdout);
#endif

int t;
cin>>t;
for(int i=0;i<t;i++){
    int n;
    cin>>n;
int arr[n];
cout<<output(arr,n);
}


return 0;}