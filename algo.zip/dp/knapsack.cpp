#include<bits/stdc++.h>
using namespace std;


int main()
{
#ifndef ONLINE_JUDGE
freopen("input.txt", "r", stdin);
freopen("output.txt", "w", stdout);
#endif

long int N,W;
cin>>N>>W;
long int w[N+1];
int v[N];

for(int i=0;i<N;i++){
    cin>>w[i+1]>>v[i];
}


long int t[N+1][W+1];
for(int i=0;i<N+1;i++){
    for(int j=0;j<W+1;j++){
        if(i==0||j==0)t[i][j]=0;
    else{
    if(w[i]>j)t[i][j]=t[i-1][j];
    else t[i][j]=max(t[i-1][j],v[i-1]+t[i-1][j-w[i]]);
    }
    }
}

cout<<t[N][W];

    return 0;
}