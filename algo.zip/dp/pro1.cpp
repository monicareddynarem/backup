#include<bits/stdc++.h>
using namespace std;

/*
There are N stones, numbered 1,2,…,N. For each i (1≤i≤N), the height of Stone i is 
hi. 
​There is a frog who is initially on Stone 1. 
He will repeat the following action some number of times to reach Stone N:
 If the frog is currently on Stone i, jump to Stone i+1 or Stone i+2. Here, a cost of |hi-hj|
 where j is the stone to land on.
 Find the minimum possible total cost incurred before the frog reaches Stone 
N.

*/
int mod(int a){
    if(a>=0)return a;
    return -a;
}

int main(){
    int N;
    cin>>N;
    int h[N];
    for(int i=0;i<N;i++){
        cin>>h[i];
    }

    int dp[N];
    dp[0]=0;
    dp[1]=mod(h[1]-h[0]);
    for(int i=2;i<N;i++){
       dp[i]=min(dp[i-1]+mod(h[i]-h[i-1]),dp[i-2]+mod(h[i]-h[i-2]));
    }

    cout<<dp[N-1];


    return 0;
}