#include<bits/stdc++.h>
using namespace std;


int main()
{
#ifndef ONLINE_JUDGE
freopen("input.txt", "r", stdin);
freopen("output.txt", "w", stdout);
#endif

int n,m;
cin>>n>>m;
char arr[n][m];
for(int i=0;i<n;i++){
    for(int j=0;j<m;j++){
        cin>>arr[i][j];
    }
}


int up=0;
while(true){
    int p=1;
    for(int j=0;j<m;j++){
        if(arr[up][j]=='*'){
            p=0;
            break;
        }
    }
    if(p==0)break;
    up++;
}



int down=n-1;
while(true){
    int p=1;
    for(int j=0;j<m
    ;j++){
        if(arr[down][j]=='*'){
            p=0;
            break;
        }
    }
    if(p==0)break;
    down--;
}

int left=0;
while(true){
    int p=1;
    for(int j=up;j<=down;j++){
        if(arr[j][left]=='*'){
            p=0;
            break;
        }
    }
    if(p==0)break;
    left++;
}

int right=m-1;
while(true){
    int p=1;
    for(int j=up;j<=down;j++){
        if(arr[j][right]=='*'){
            p=0;
            break;
        }
    }
    if(p==0)break;
    right--;
}


for(int j=up;j<=down;j++){
    for(int i=left;i<=right;i++){
        cout<<arr[j][i]<<" ";
    }
    cout<<endl;
}


    return 0;
}