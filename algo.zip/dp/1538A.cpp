#include<bits/stdc++.h>
using namespace std;

int minim(int a,int b,int c){
    if(a<b && a<c)return a;
    if(b<a && b<c)return b;
    if(c<b && a>c)return c;
}

int output(int arr[],int n){
    int maxi=arr[0];
    int max_idx=0;
    int mini=arr[0];
    int min_idx=0;
    for(int i=0;i<n;i++){
        if(arr[i]>maxi){
            maxi=arr[i];
            max_idx=i;
        }
        if(arr[i]<mini){
            mini=arr[i];
            min_idx=i;
        }
    }

if(min_idx<= n/2 && max_idx<=n/2)return max(min_idx,max_idx)+1;
if(min_idx>= n/2 && max_idx>=n/2)return n-min(min_idx,max_idx);
if(min_idx <=n/2 && max_idx>=n/2){
    return minim(n-max_idx+min_idx+1,max_idx+1,n-min_idx);
}
if(min_idx >=n/2 && max_idx<=n/2){
    return minim(n-min_idx+max_idx+1,min_idx+1,n-max_idx);
}

}


int main()
{
#ifndef ONLINE_JUDGE
freopen("input.txt", "r", stdin);
freopen("output.txt", "w", stdout);
#endif

int t;
cin>>t;

for(int i=0;i<t;i++){
    int n;
    cin>>n;
    int arr[n];
    for(int j=0;j<n;j++){
        cin>>arr[j];
    }

    cout<<output(arr,n)<<endl;
}

    return 0;
}