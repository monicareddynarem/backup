#include<bits/stdc++.h>
using namespace std;
int main()
{

#ifndef ONLINE_JUDGE
freopen("input.txt", "r", stdin);
freopen("output.txt", "w", stdout);
#endif


string X,Y;
cin>>X>>Y;
int rows=X.length()+1;
int cols=Y.length()+1;

int LCS[rows][cols];

for(int i=0;i<rows;i++){
    for(int j=0;j<cols;j++){
        if(i==0 || j==0){
            LCS[i][j]=0;
        }
        else if(X[i-1]==Y[j-1]){
            LCS[i][j]=1+LCS[i-1][j-1];
        }
        else{
            LCS[i][j]=max(LCS[i-1][j],LCS[i][j-1]);
        }
    }
}


int i=rows-1;
int k=cols-1;
string lcs="";

while(i>=1 && k>=1){

    if(X[i-1]==Y[k-1]){
       lcs.push_back(X[i-1]);
       i--;
       k--;
    }
    else if(LCS[i-1][k]>=LCS[i][k-1]){
        i--;
    }
    else k--;
}

reverse(lcs.begin(),lcs.end());
cout<<lcs;

    return 0;
}