#include<iostream>
using namespace std;

int mod(int a){
    if(a>=0)return a;
    return -a;
}

int main()
{ int N,K;
    cin>>N>>K;
    int h[N];
    for(int i=0;i<N;i++){
        cin>>h[i];
    }

    int dp[N];
    dp[0]=0;
    dp[1]=mod(h[1]-h[0]);

for(int i=2;i<N;i++){
     int mini=dp[i-1]+mod(h[i]-h[i-1]);
       for(int j=1;j<=K;j++){
        if(i>=j){
         dp[i]=min(mini,dp[i-j]+mod(h[i]-h[i-j]));
         mini=min(mini,dp[i-j]+mod(h[i]-h[i-j]));
        }
    }
}

    cout<<dp[N-1];

    return 0;
}