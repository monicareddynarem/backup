#include<iostream>
using namespace std;


int mod(int a){
    if(a>=0)return a;
    return -a;
}

int main(){
    int N;
    cin>>N;
    int h[N];
    for(int i=0;i<N;i++){
        cin>>h[i];
    }

    int dp[N];
    dp[0]=0;
    return 0;
}