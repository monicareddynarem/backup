#include<bits/stdc++.h>
using namespace std;

int max(int a,int b,int c){
    if(a>b && a>c)return a;
    if(b>c && b>a)return b;
    if(c>a && c>b)return c;
}


int main()
{  
#ifndef ONLINE_JUDGE
freopen("input.txt", "r", stdin);
freopen("output.txt", "w", stdout);
#endif

int N;
cin>>N;
int a[N],b[N],c[N];

for(int i=0;i<N;i++){
    cin>>a[i]>>b[i]>>c[i];
}

int dp[N][3];
dp[0][0]=a[0];
dp[0][1]=b[0];
dp[0][2]=c[0];

for(int i=1;i<N;i++){
dp[i][0]=a[i]+max(dp[i-1][1],dp[i-1][2]);
dp[i][1]=b[i]+max(dp[i-1][0],dp[i-1][2]);
dp[i][2]=c[i]+max(dp[i-1][1],dp[i-1][0]);
}

int p=max(dp[N-1][0],dp[N-1][1],dp[N-1][2]);
cout<<p;
    return 0;
}