#include<bits/stdc++.h>
using namespace std;


int main()
{
    
// #ifndef ONLINE_JUDGE
// freopen("input.txt", "r", stdin);
// freopen("output.txt", "w", stdout);
// #endif


long int n;
cin>>n;
long int dp[n+1];

dp[0]=0;

 for (long int i = 1; i <= n; i++) {
        dp[i] = INT_MAX;
    }

int denominations[] = {1, 5, 10, 20, 100};
    int num_denominations = 5;

    // Fill the dp array
    for (long int i = 1; i <= n; i++) {
        for (int d = 0; d < num_denominations; d++) {
            if (i >= denominations[d]) {
                dp[i] = min(dp[i], dp[i - denominations[d]] + 1);
            }
        }
    }

    cout << dp[n];

    return 0;
}